#! /usr/bin/env python
# -*- coding: utf-8 -*-

#
# Copyright 2020 Hewlett-Packard Development Company, L.P.
#
"""
OWS Stratus CI Credentials for ADO (Azure DevOps) UCDE E2E testing pipeline
"""

import os


class CredentialCIError(Exception):
    pass


class CredentialsCI(object):
    def __init__(self, environment):
        self._environment = environment

    def get_ows_stratus_ci_credentials(self):
        try:

            ado_stack = self._environment

            if ado_stack is None:
                raise ValueError('ADO STACK Environment Variable is None')

            ado_files_dir = os.environ['ADO_WORK_DIR']
            if ado_files_dir is None:
                raise ValueError('Environment Variable Value is None or is Incorrect')

            ows_stratus_ci_credentials = dict()

            client_id_sec_file = '{}/{}-ows_stratus_ci_client_id_sec_file'.format(ado_files_dir, ado_stack)

            client_secret_sec_file = '{}/{}-ows_stratus_ci_client_secret_sec_file'.format(ado_files_dir, ado_stack)

            if os.path.exists(client_id_sec_file):
                try:
                    with open(client_id_sec_file) as _client_id_sec_file:
                        client_id = _client_id_sec_file.read()
                except IOError:
                    raise IOError('Secured File ows_stratus_ci_client_id Not Found')
                else:
                    ows_stratus_ci_credentials['authz_client_id'] = client_id
                    _client_id_sec_file.close()

            if os.path.exists(client_secret_sec_file):
                try:
                    with open(client_secret_sec_file) as _client_secret_sec_file:
                        client_secret = _client_secret_sec_file.read()
                except IOError:
                    raise IOError('Secured File ows_stratus_ci_client_secret_file Not Found')
                else:
                    ows_stratus_ci_credentials['authz_client_secret'] = client_secret
                    _client_secret_sec_file.close()

            return ows_stratus_ci_credentials
        except ValueError:
            raise CredentialCIError
