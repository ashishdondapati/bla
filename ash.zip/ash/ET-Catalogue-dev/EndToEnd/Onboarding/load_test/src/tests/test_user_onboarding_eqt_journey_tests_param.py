class Param(object):
    stack = None
    hp_id_token = None
    user_access_token = None
    service_access_token = None
    delegated_token = None
    consents = None
    delegated_token_with_elevated_scopes = None
    user_id = None
    session_id = None