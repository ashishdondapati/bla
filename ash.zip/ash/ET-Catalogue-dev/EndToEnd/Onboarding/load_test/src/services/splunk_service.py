import json
import requests
import os
from config import URLS


def push_suite_test_data(event):
    disable_agent_proxy()

    splunk_token = get_splunk_token()
    headers = {'Authorization': 'Splunk ' + splunk_token}
    r = requests.post(URLS["splunk_uri"], data=json.dumps(event), headers=headers, verify=False)
    print(r.content)


def get_splunk_token():
    ado_files_dir = os.environ['ADO_WORK_DIR']
    ows_stratus_ci_splunk_token_sec_file = '{}/ows_stratus_ci_splunk_token_sec_file'.format(ado_files_dir)
    if os.path.exists(ows_stratus_ci_splunk_token_sec_file):
        try:
            with open(ows_stratus_ci_splunk_token_sec_file) as splunk_token_sec_file:
                splunk_id_token = splunk_token_sec_file.read()
                return splunk_id_token
        except IOError:
            raise IOError('Secured File ows_stratus_ci_splunk_token_sec_file Not Found')


def disable_agent_proxy():

    http_proxy = os.environ["HTTP_PROXY"] = ""
    print("HTTP Proxy: {}".format(http_proxy))

    https_proxy = os.environ["HTTPS_PROXY"] = ""
    print("HTTPS Proxy: {}".format(https_proxy))