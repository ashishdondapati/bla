#! /usr/bin/env python
# -*- coding: utf-8 -*-

#
# Copyright 2020 Hewlett-Packard Development Company, L.P.
#

from copy import deepcopy
from requests.auth import HTTPBasicAuth
import json

# User Defined Exceptions
from exceptions.stratus_authz_http_error import StratusAuthZHTTPError
from exceptions.stratus_authz_error import StratusAuthZError

from config import _DEFAULT_HEADER, STRATUS_AUTHZ_SERVER_STACKS as SERVER_STACKS

from urllib import parse
from jwt import algorithms
import jwt

import requests

import warnings
warnings.filterwarnings("ignore")


def get_metadata(stack='pie'):

    headers = None

    resp = None

    try:
        url = '{}/.well-known/openid-configuration'.format(SERVER_STACKS[stack]['stratus_authz_uri'])
        headers = deepcopy(_DEFAULT_HEADER)
        headers.update({'Accept': '*/*'})
        resp = requests.get(url, headers=headers, verify=False)
        resp.raise_for_status()
    except requests.HTTPError as http_error:
        raise StratusAuthZHTTPError(http_error, headers, None, resp)
    except Exception as err:
        raise StratusAuthZError(err)
    else:
        metadata = json.loads(resp.text)
    return metadata


def get_jwks(stack='pie', url=None):
    #
    # To use with Stratus AuthZ metadata:
    #   keys = stratus_authz.get_jwks(url=stratus_authz.get_metadata()['jwks_uri'])
    #

    resp = None

    try:
        if url is None:
            url = '{}/openid/v1/jwks.json'.format(SERVER_STACKS[stack]['stratus_authz_uri'])

        resp = requests.get(url, verify=False)
        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise StratusAuthZHTTPError(http_error, None, None, resp)
    except Exception as err:
        raise StratusAuthZError(err)
    else:
        keys = json.loads(resp.text)
    return keys


def verify_token(access_token, jwks=None, stack='pie'):

    if jwks is None:
        jwks = get_jwks(stack)

    headers = jwt.get_unverified_header(access_token)
    algorithm = headers['alg']
    kid = headers['kid']

    public_key = None
    for jwk in jwks['keys']:
        if jwk['kid'] == kid:
            public_key = jwt.algorithms.get_default_algorithms()[algorithm].from_jwk(json.dumps(jwk))
            break

    if public_key is None:
        raise StratusAuthZError('Could not get public key for algorithm={}, jwks={}\n'.format(algorithm, jwks))


def introspect_token(access_token, stack='pie', url=None):
    #
    # To use with Stratus AuthZ metadata:
    #   claim_set = stratus_authz.introspect_token(access_token,
    #                                              url=stratus_authz.get_metadata()['introspection_endpoint'])
    #

    headers = None

    data = None

    resp = None

    try:
        if url is None:
            url = '{}/openid/v1/introspect'.format(SERVER_STACKS[stack]['stratus_authz_uri'])

        headers = deepcopy(_DEFAULT_HEADER)
        headers.update({'Content-Type': 'application/x-www-form-urlencoded',
                        'Accept': 'application/json',
                        'Authorization': 'Bearer {}'.format(access_token)})

        data = 'token={}&token_type_hint=access_token'.format(access_token)

        resp = requests.post(url,
                             verify=False,
                             data=data,
                             headers=headers)

        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise StratusAuthZHTTPError(http_error, headers, data, resp)
    except Exception as err:
        raise StratusAuthZError(err)
    else:
        claim_set = json.loads(resp.text)

    return claim_set


def get_service_access_token(stack='pie', url=None):
    #
    # To use with Stratus AuthZ metadata:
    #   service_access_token = stratus_authz.get_service_access_token(
    #                                        url=stratus_authz.get_metadata()['token_endpoint'])
    #

    headers = None

    data = None

    resp = None

    try:
        if url is None:
            url = '{}/openid/v1/token'.format(SERVER_STACKS[stack]['stratus_authz_uri'])

        headers = deepcopy(_DEFAULT_HEADER)
        headers.update({'Content-Type': 'application/x-www-form-urlencoded',
                        'Accept': 'application/json'})

        auth = HTTPBasicAuth(SERVER_STACKS[stack]['stratus_authz_id'], SERVER_STACKS[stack]['stratus_authz_secret'])

        data = 'grant_type=client_credentials'

        resp = requests.post(url,
                             verify=False,
                             data=data,
                             auth=auth,
                             headers=headers)
        resp.raise_for_status()
    except requests.HTTPError as http_error:
        raise StratusAuthZHTTPError(http_error, headers, data, resp)
    except Exception as err:
        raise StratusAuthZError(err)
    else:
        body = json.loads(resp.text)
        service_access_token = body['access_token']
    return service_access_token


def exchange_access_token(access_token, stack='pie', url=None):
    #
    # To use with Stratus AuthZ metadata:
    #   user_access_token = stratus_authz.exchange_access_token(base_access_token,
    #                                                           url=stratus_authz.get_metadata()['token_endpoint'])
    #

    # NOTE: access token originally generated by OWS cannot be exchanged by OWS for another access token.
    # This means that we can only exchange an access token that came from another AuthZ client, such as the Smart Apps.

    headers = None

    data = None

    resp = None

    try:

        if url is None:
            url = '{}/openid/v1/token'.format(SERVER_STACKS[stack]['stratus_authz_uri'])

        params = {'grant_type': 'urn:ietf:params:oauth:grant-type:token-exchange',
                  'subject_token_type': 'urn:ietf:params:oauth:token-type:access_token',
                  'subject_token': '{}'.format(access_token)}

        data = parse.urlencode(params)

        headers = {'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json'}

        resp = requests.post(url,
                             verify=False,
                             data=data,
                             auth=HTTPBasicAuth(SERVER_STACKS[stack]['stratus_authz_id'],
                                                SERVER_STACKS[stack]['stratus_authz_secret']),
                             headers=headers)

        resp.raise_for_status()
    except requests.HTTPError as http_error:
        raise StratusAuthZHTTPError(http_error, headers, data, resp)
    except Exception as err:
        raise StratusAuthZError(err)
    else:
        body = json.loads(resp.text)
        output_access_token = body['access_token']

    return output_access_token
