class UCDEError(RuntimeError):
    def __init__(self, _error):
        self.error = _error
        self.message = 'UCDE Error: \n\t{} '.format(_error)

