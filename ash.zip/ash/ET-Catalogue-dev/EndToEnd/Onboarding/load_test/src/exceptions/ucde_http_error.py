import json


class UCDEHTTPError(RuntimeError):
    def __init__(self, _error, _headers, _data, _resp):
        self.error = _error
        self.resp = _resp
        if 'Authorization' in _headers:
            _headers['Authorization'] = 'Hidden'
        self.message = 'UCDE HTTP Error: ' \
                       '\n\t{} ' \
                       '\nUCDE HTTP Header: ' \
                       '\n\t{}' \
                       '\nUCDE HTTP Request: ' \
                       '\n\tbody = {}' \
                       '\nUCDE HTTP Response: ' \
                       '\n\tbody = {}'.format(_error, _headers, json.dumps(_data), _resp.text)
