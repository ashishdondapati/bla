class StratusAuthZError(RuntimeError):
    def __init__(self, _error):
        self.error = _error
        self.message = 'Stratus AuthZ Error: \n\t{} '.format(_error)
