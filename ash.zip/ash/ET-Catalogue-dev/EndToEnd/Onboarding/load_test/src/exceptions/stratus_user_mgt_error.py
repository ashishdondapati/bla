class StratusUserMgtError(RuntimeError):
    def __init__(self, _error):
        self.error = _error
        self.message = 'Stratus User Mgt Error: \n\t{} '.format(_error)
