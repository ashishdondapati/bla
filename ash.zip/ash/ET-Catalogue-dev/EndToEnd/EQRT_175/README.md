# Print On The Go (POTG) Hero Flows 
Jira link: https://jira.cso-hp.com/browse/EQTR-175