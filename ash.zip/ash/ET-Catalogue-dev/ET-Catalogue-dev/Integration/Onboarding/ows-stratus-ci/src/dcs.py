#! /usr/bin/env python
# -*- coding: utf-8 -*-

#
# Copyright 2020 Hewlett-Packard Development Company, L.P.
#
"""
Device Claim Service test harnesses
"""
import base64
import json
import requests
from copy import deepcopy

from config import _DEFAULT_HEADER, PROXIES, PROFILES

import warnings

from exceptions.dcs_error import DCSError
from exceptions.dcs_http_error import DCSHTTPError

warnings.filterwarnings("ignore")

sim_base_uri = 'https://g2sim.wpp.api.hp.com'


def create_simulated_gen2_printer(stack='pie', profile='palermo', biz_model=None, offer=0):
    # https://rndwiki.corp.hpicorp.net/confluence/pages/viewpage.action?title=Printer+Simulator+APIs&spaceKey=IWSWebPlatform

    # Supported Stacks
    #    pie
    #    stage

    # Supported Profiles
    # | profile          | model number |
    # +------------------+--------------+
    # | limo             | A7W94A       |
    # | palermo          | K7R96A       |
    # | ellis            | Y0S19A       |
    # | verona           | M2U75A       |
    # | palermolow       | K7G18A       |
    # | palermolowder1   | K7G93A       |
    # | infinitybaseder2 | 2RY54A       |
    # | skyreach         | 6GX01A       |
    # | manhattan_yeti   | 1G5M1A       |

    headers = None

    data = None

    resp = None

    try:
      
        create_payload = {"stack": stack, "profile": profile, "biz_model": biz_model}

        if biz_model:
            create_payload.update({"fipsflag": "true", "offer": offer})

        # create printer
        headers = deepcopy(_DEFAULT_HEADER)
        headers.update({'Content-Type': 'application/json'})
        data = json.dumps(create_payload)
        resp = requests.post('{}/wpp/simulator/printers'.format(sim_base_uri),
                             headers=headers,
                             data=data,
                             verify=False,
                             proxies=PROXIES)

        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise DCSHTTPError(http_error, headers, data, resp)
    except Exception as err:
        raise DCSError(err)
    else:
        body = resp.json()
        serial_number = body['entity_id']

        gen2_device = {}
        gen2_device.update(PROFILES[profile])
        gen2_device['uuid'] = body['uuid']
        gen2_device['serialNumber'] = serial_number
    return register_printer(serial_number=serial_number, gen2_device=gen2_device)


def register_printer(serial_number=None, gen2_device=None):

    headers = None

    resp = None

    try:

        headers = _DEFAULT_HEADER

        resp = requests.post('{}/wpp/simulator/printers/{}/register'.format(sim_base_uri, serial_number),
                             headers=headers,
                             verify=False,
                             proxies=PROXIES)

        resp.raise_for_status()
    except requests.HTTPError as http_error:
        raise DCSHTTPError(http_error, headers, None, resp)
    except Exception as err:
        raise DCSError(err)
    else:
        body = resp.json()
        gen2_device['cloud_id'] = body['cloud_id']
        return claim_postcard(serial_number=serial_number, gen2_device=gen2_device)


def claim_postcard(serial_number=None, gen2_device=None):

    headers = None

    resp = None

    try:

        headers = _DEFAULT_HEADER

        resp = requests.post('{}/wpp/simulator/printers/{}/claimpostcard'.format(sim_base_uri, serial_number),
                             headers=_DEFAULT_HEADER,
                             verify=False,
                             proxies=PROXIES)

        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise DCSHTTPError(http_error, headers, None, resp)
    except Exception as error:
        raise DCSError(error)
    else:
        gen2_device['claimPostcard'] = base64.standard_b64encode(resp.content)
    return generate_claim_code(serial_number=serial_number, gen2_device=gen2_device)


def generate_claim_code(serial_number, gen2_device=None):

    headers = None

    data = None

    resp = None

    try:
        headers = deepcopy(_DEFAULT_HEADER)
        headers.update({'Content-Type': 'application/json'})
        data = json.dumps({"version": 1, "serial_number": serial_number, "issuance_count": 2, "instant_ink": True,
                           "ownership_counter": 2})
        resp = requests.post('{}/wpp/tools/printercode'.format(sim_base_uri),
                             headers=headers,
                             data=data,
                             verify=False,
                             proxies=PROXIES)
        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise DCSHTTPError(http_error, headers, data, resp)
    except Exception as error:
        raise DCSError(error)
    else:
        return get_fingerprint(serial_number=serial_number, gen2_device=gen2_device)


def get_fingerprint(serial_number, gen2_device=None):

    headers = None

    resp = None

    try:
        if gen2_device is None:
            gen2_device = {}

        headers = _DEFAULT_HEADER
        resp = requests.get('{}/wpp/simulator/printers/{}/devicefingerprint'.format(sim_base_uri, serial_number),
                            headers=headers, verify=False, proxies=PROXIES)
        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise DCSHTTPError(http_error, headers, None, resp)
    except Exception as error:
        raise DCSError(error)
    else:
        gen2_device['cdmPrinterFingerprint'] = base64.standard_b64encode(resp.content)
    return gen2_device


