class IOError (RuntimeError):
    def __init__(self, _error):
        self.error = _error
        self.message = 'Error writing file to Output: \n\t{} '.format(_error)