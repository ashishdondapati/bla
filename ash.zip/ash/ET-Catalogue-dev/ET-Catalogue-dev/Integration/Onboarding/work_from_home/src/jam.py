#! /usr/bin/env python
# -*- coding: utf-8 -*-

#
# Copyright 2020 Hewlett-Packard Development Company, L.P.
#

from copy import deepcopy
from requests.auth import HTTPBasicAuth
import json

# User Defined Exceptions
from exceptions.jam_auth_http_error import JAMAuthHTTPError
from exceptions.jam_auth_error import JAMAuthenticationError as JamAuthError

from config import _DEFAULT_HEADER, JAM_AUTH_SERVER_STACKS as SERVER_STACKS
from config import JAM_SERVER_STACKS


import requests

import warnings

warnings.filterwarnings("ignore")


# Get Auth Token for JAM API's
def get_jam_AuthToken(stack='stage'):
    headers = {}

    try:
        url = '{}/oauth/v2/token'.format(SERVER_STACKS[stack]['jam_authz_uri'])
        headers.update({'Accept': '*/*'})
        headers.update({"Content-Type":"application/x-www-form-urlencoded", "User-Agent":"PostmanRuntime/7.26.8"})
        payload = {'username': SERVER_STACKS[stack]['jam_username'], "password": SERVER_STACKS[stack]['jam_password'],
             'scope': 'GLOBAL', 'grant_type': 'password'}
        auth = (SERVER_STACKS[stack]['jam_authz_id'], SERVER_STACKS[stack]['jam_authz_secret'])
        resp = requests.post(url, auth=auth, headers=headers, data=payload, verify=False)
        resp.raise_for_status()
    except requests.HTTPError as http_error:
        raise JAMAuthHTTPError(http_error, headers, None, resp)
    except Exception as err:
        raise JamAuthError(err)
    else:
        body = resp.json()
        access_token = body['access_token']

        return access_token


# Creates the device for Customer in JAM  and returns boolean value
def add_device_in_jam(serialnumber, modelname, productnumber, stack='stage', company = None, ipaddress='0.0.0.0',
                      programname='ws-hp.com/wfh'):
    headers = {}
    payload = {}
    resp = None
    result = None
    try:

        url = 'https://stage.jamanagement.api.hp.com/jetadv/v3/Customers/' + str(company) + '/Devices'#.format(JAM_SERVER_STACKS[stack]['jam_base_uri'])

        access_token = get_jam_AuthToken(stack=stack)
        headers.update({"Authorization": "Bearer " + access_token})
        headers.update({"Content-Type": "application/json"})
        payload= json.dumps({'ModelName': modelname, "SerialNumber": serialnumber, 'IpAddress': ipaddress, 'ProgramName': programname,
                        'ProductNumber': productnumber})
        resp = requests.post(url, headers=headers, data=payload, verify=False)
        resp.raise_for_status()

    except requests.HTTPError as http_error:
        raise JAMAuthHTTPError(http_error, headers, None, resp)
    except Exception as err:
        raise JamAuthError(err)
    else:
        status = resp.status_code
        body = resp.json()
        guid = body["Guid"]
    return guid

