# EQT-Catalogue
Automatic Test Catalogue

## Onboarding Journey Tests Framework 
### (Formely OWS Stratus CI - Continuous Integration) 

This project runs continuous integration pipelines that executes End-To-End user and device onboarding tests.

Those tests call APIs from Stratus and UCDE.

### Onboarding Journey Tests Framework - Architecture

<img src="https://github-partner.azc.ext.hp.com/Ecosystem-Trunk/ET-Catalogue/blob/dev/doc/imgs/onboarding_journey_tests_framework.png"  width="900" height="500">

### Onboarding Journey Tests Framework - Create a suite test

<img src="https://github-partner.azc.ext.hp.com/Ecosystem-Trunk/ET-Catalogue/blob/dev/doc/imgs/create_onboarding_suite_test.png"  width="300" height="650">

### Onboarding Journey Tests Framework - Microservices API's

<img src="https://github-partner.azc.ext.hp.com/Ecosystem-Trunk/ET-Catalogue/blob/dev/doc/imgs/microservices_apis.png"  width="900" height="250">



# GFriend Description

GFriend is designed as a Declaritive language.

## GFriend Guidelines
Followings are some decision point to add functionality (and add keyword) at GFriend:
1.	Can be used for various test and can be provided in simple format
2.	Can be covered by combination of existing keywords 
  a. create custom library
3.	Complex and very specific cases. 
  a. Analyze base test case and find way to accomplish the goal of test case in other way.
4.	Complex but essential. Create new keyword (or library) with more abstraction - https://github.azc.ext.hp.com/HP-SMT/GFriend 
  a. For example, Windows.Open File For Print keyword open document, open print dialog, select printer queue, and open driver properties. 

## GFriend Executable locations - All point to the GFriend binaries 
  \\rdlfs.etl.boi.rd.hpicorp.net\public\Mphasis\RonP\GFriend
  http://130.31.193.61/ 
## Training links:
  https://web.microsoftstream.com/channel/fce270bb-9dec-4a3c-9e38-988e769696d6

# Shortcuts
Parent Jira Story - Automation stories to be completed are User Stories linked to Epics through this site:
  https://jira.cso-hp.com/browse/PSPI-1707


# OWS Stratus CI (Continuous Integration)

This project runs continuous integration pipelines that executes End-To-End user and device onboarding tests.

Those tests call APIs from Stratus and UCDE.

## Setting Up Local Environment

### Windows 

#### Install [pyenv-win](https://pypi.org/project/pyenv-win/)

pip install pyenv-win

#### Install python 3.8.0
    pyenv install 3.8.0
    pyenv global 3.8.0
    
#### Install python test framework [pytest](https://pypi.org/project/pytest/)
The End-To-End user and device onboarding suite tests uses [Python Test Framework - Pytest](https://docs.pytest.org/en/latest/).

### Clone repository
1. [Sign in to GitHub](https://github.azc.ext.hp.com/)

2. Clone repository either via HTTPS or SSH
	-	HTTPS		
            ```
                git clone https://<username>:<access_token>@github.azc.ext.hp.com/ows/ows-stratus-ci.git
            ```
	-	SSH (Not supported outside HP Firewall)
		[Create a new ssh key and add it to your GitHub account](https://help.github.com/articles/generating-an-ssh-key/) 
            ```
                git clone git@github.azc.ext.hp.com:ows/ows-stratus-ci.git
            ```
3.	[Create a new personal access token in your GitHub settings](https://github.azc.ext.hp.com/settings/tokens)
4.	Set up HTTP proxy
        ```
            git config --global http.proxy web-proxy.corp.hp.com:8080
        ```
5.	Set up HTTPS proxy
        ```
            git config --global https.proxy web-proxy.corp.hp.com:8080
        ```
---       
### IDE
Install [PyCharm](https://www.jetbrains.com/pycharm/)

##### In Pycharm open the project at <workspace>/ows-oss/src. Create the virtual environment for this project using Python 3.8.0 (installed by pyenv).
    PyCharm -> Preferences -> Project {project name} -> ProjectInterpreter

Select the gear icon in on the top right of the project interpreter dropdown. 

Now choose “Create VirtualEnv” in the subsequent dialog choose the 3.8.10 interpreter and leave “Inherit global site-packages” unchecked.
After the virtual env is created choose it in the Project Interpreter drop-down.
The bottom panel should then list the python packages installed for this env. Close this window

##### From the `src` directory run the following command to install the proper dependencies
    pip install -r requirements.txt
<sub>Verify in the window from the previous step that the dependencies in requirements.txt display properly.</sub>

In PyCharm create a run configuration -- choose Python as the type

Set `Name` to something like “test_user_onboarding” and another one for "test_device_onboarding.py" 

Set `Script` to `\tests\test_user_onboarding.py` and another one Set `Script` to `\tests\test_device_onboarding`

Set `Script parameters` to:  `--env=pie –debug` or to: `--env=stage -debug`
 
Set `Python interpreter` to the virtual env you created

Set `Working directory` to the `src` directory in the repo
    
### Veryfing Azure DevOps (ADO) - OWS Stratus CI Tropos Environment

1. Login [AzureDevOps](https://dev.azure.com/) with HP Credentials

2. Click on HPCodeWay Organization

3. Click on UCDE Project

4. Select Pipelines 

5. It will display the following ows-stratus-ci pipelines:

	a) pie-ows-stratus-ci: It runs on pie stack and it is triggered by UCDE service deployment.
  
	b) pie-schedule-ows-stratus-ci: It runs on pie stack and it is scheduled to run every hour.
  
	c) stage-ows-stratus-ci: It runs on stage stack and it is triggered by UCDE service deployment.
  
	d) stage-schedule-ows-stratus-ci: It runs on stage stack and it is scheduled to run every hour.


