# -*- coding: utf-8 -*-
"""
Created on Tue Aug 17 11:10:38 2021

@author: user
"""


'''
import os
fileDir = r"C:\Users\user\Desktop\dashboard1\htmlfiles"
fileExt = r".xml"
files=[_ for _ in os.listdir(fileDir) if _.endswith(fileExt)]

import xml.dom.minidom
for file in files:
  doc=xml.dom.minidom.parse(file)
  print(doc.nodeName)
  print(doc.firstChild.tagName)
 
expertise=doc.getElementsByTagName("expertise")
print("%d expertise:"% expertise.length)



def printLines():
    print("=" * 80)
    
printLines()   
================================================================================================== 
'''

#https://machinehack.com/hackathons/data_hack_mathcothon_car_price_prediction_challenge/overview
#https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.merge.html



gfront ,robot 

otput.xml

store in sql

trunk ci



testresult['dispatcher']
testresult['testsuite.lv1'] = options.tsuitelv1
testresult['testsuite.lv2'] = options.tsuitelv2

testresult['run.session.id'] = options.sessionid
testresult['config.stack'] = options.stack
testresult['config.productkey'] = options.prdkey
testresult['config.dutid'] = options.dutid
testresult['config.fwversion'] = version
testresult['info.locaiton'] = options.tlocation
testresult['ts_start'] = ts_start.strftime("%Y-%m-%d %H:%M:%S")
testresult['ts_end'] = ts_end.strftime("%Y-%m-%d %H:%M:%S")
testresult['result.passrate'] = '%2.1f%%' % (result.suite.statistics.all.passed * 100 / result.suite.statistics.all.total)
testresult['result.count.total'] = result.suite.statistics.all.total
testresult['result.count.passed'] = result.suite.statistics.all.passed
testresult['result.count.failed'] = result.suite.statistics.all.failed
testresult['testsuite.lv3'] = result.suite.name
 