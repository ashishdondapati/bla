# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import pandas as pd 
import numpy as np 
train=pd.read_csv('train.csv')
test=pd.read_csv('test.csv')

test.info()

train.isnull().values.any()
#df['your column name'].isnull().sum()
train.info()
train.describe()

from sklearn.linear_model import LinearRegression
regressor=LinearRegression()
train.dropna(how='all')
train.nunique()

train['Leather interior'].unique()
d = { 'Yes' : 1,'No':0}
train.replace({'Leather interior': d})

test['Leather interior'].unique()
d = { 'Yes' : 1,'No':0}
test.replace({'Leather interior': d})


train['Fuel type'].unique()
train['Doors'].unique()
train['Drive wheels'].unique()
train['Model'].unique()
train['Mileage'].unique()
train['Mileage'].value_counts()


one_hot_encoded_data = pd.get_dummies(train, columns = ['Manufacturer', 'Model','Levy','Category','Prod. year','Fuel type','Engine volume','Mileage','Cylinders','Gear box type','Drive wheels','Doors','Wheel','Color','Airbags'])
type(one_hot_encoded_data)
one_hot_encoded_data.head()
train=train.drop(['ID'],axis=1)
train.head()
training=pd.concat([train,one_hot_encoded_data],axis=1)
training.head()

one_hot_encoded_data_2 = pd.get_dummies(test, columns = ['Manufacturer', 'Model','Levy','Category','Prod. year','Fuel type','Engine volume','Mileage','Cylinders','Gear box type','Drive wheels','Doors','Wheel','Color','Airbags'])
type(one_hot_encoded_data_2)
one_hot_encoded_data_2.head()
test=test.drop(['ID'],axis=1)
test.head()
testing=pd.concat([test,one_hot_encoded_data_2],axis=1)
testing.head()


y=training[['Price']]
x=training.drop(['Price'],axis=1)
x.head()
x.info()

val_x=testing.drop(['Price'],axis=1)


#x.to_csv('a.csv')
x=x.drop(['Leather interior'], axis = 1)
k=x.select_dtypes(include=['object']).columns.tolist()
print(k)
x=x.drop(x.loc[:, 'Levy':'Color'].columns, axis = 1)

val_x=val_x.drop(['Leather interior'], axis = 1)
o=val_x.select_dtypes(include=['object']).columns.tolist()
print(o)
val_x=val_x.drop(val_x.loc[:, 'Levy':'Color'].columns, axis = 1)

from sklearn.preprocessing import MinMaxScaler
scaler=MinMaxScaler()
scaler.fit(x)
scaler.transform(x)

scaler2=MinMaxScaler()
scaler2.fit(val_x)
scaler2.transform(val_x)

from sklearn.linear_model import LinearRegression
reg=LinearRegression()
reg.fit(x,y)
import pickle
filename='model.sav'
pickle.dump(reg, open(filename, 'wb'))
'''
loaded_model = pickle.load(open(filename, 'rb'))
result = loaded_model.score(X_test, Y_test)
print(result)
'''
actual=pd.read_csv('submission.csv')

predicted=reg.predict(val_x)
from sklearn.metrics import mean_squared_log_error
rmsle=np.sqrt(mean_squared_log_error(actual, predicted)) 
predicted.to_csv('my_submission_file.csv', index=False)



