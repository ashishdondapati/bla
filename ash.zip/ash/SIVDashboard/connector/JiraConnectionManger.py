"""This module handles the retrieve jira and
    Update the data into database

"""

import pyodbc
import requests
import json
import base64
import math
import datetime
import pandas as pd
import configparser
import os
from connector.SQLManager import SQLManager

cwd = os.getcwd()
config = configparser.ConfigParser()
configFile = cwd + '\\connector\\jira.ini'
config.read(configFile)


class JiraConnectionManager:
    def __init__(self):
        self.pf_stories = pd.DataFrame()
        self.stories =[]
        self.pf_bugs = pd.DataFrame()
        self.pf_bugs = pd.DataFrame()

    def get_latest_from_jira(self, type, story=''):
        """Issue a GET request (read) against the API to get all
        the issues for given project based on the filter argument
        with '' (empty) will get all the issues, otherwise get all
        the data updated during the given period ('1h'- last 1 hour update
        Update/insert the records Sql server db

        Returns:
            none
        """

        ###
        cred = "Basic " + base64.b64encode(b'manigandan.s@hp.com:Nikath@06').decode("utf-8")
        # Set header parameters
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": cred
        }
        headers = {
            'Authorization': 'Basic bWFuaWdhbmRhbi5zQGhwLmNvbTpvZERJVGRyWHUwaEswSU8yUWJkeUxpVFNoMHVPblkxT3Y0V1J2eA==',
            'Cookie': 'AWSALB=2juJ9z7fMwKa0f8V/bNJv7ffpdWySY9mylJp1x0njpT4UlESm3/XxeIf3Wtz63TBzySuumJR3MEgRA7XjW34ZtxJ5QvmENORtvL2MiwqcuxrcZAIfc0VXu1QPBRZ; AWSALBCORS=2juJ9z7fMwKa0f8V/bNJv7ffpdWySY9mylJp1x0njpT4UlESm3/XxeIf3Wtz63TBzySuumJR3MEgRA7XjW34ZtxJ5QvmENORtvL2MiwqcuxrcZAIfc0VXu1QPBRZ; JSESSIONID=0FE543BAC09BCD2DA8F0AD39A2A26B25; atlassian.xsrf.token=B6PH-08EC-IZ9H-PNPV_d5b06c157b23fc5483e239bbedbd23d042ae040b_lin'
        }

        # calculate the number of API iteration required to get all the items in the response.
        start = 0
        index = 0
        itr_cnt = 1
        maxResults = 50
        self.pf_bugs = pd.DataFrame()
        pf_epic = pd.DataFrame()
        update_filter = ''
        filter = ''
        # period that we need to get the data from jira
        if type.lower() == 'story':
            filter = config.get('Jiraserver', 'updated_time_story')
        else:
            filter = config.get('Jiraserver', 'updated_time')
        if filter != '':
            update_filter = 'AND updated >= -{}'.format(filter)

        try:
            # make API request based on the total items in the response
            while index < itr_cnt:
                start_time = datetime.datetime.now()
                projectKey = config.get('Jiraserver', 'project_key')
                url =''
                if type.lower() == 'epic':
                    url = config.get('Jiraserver', 'epic_url').format(projectKey, update_filter, start)
                elif type.lower() == 'story':
                    url = config.get('Jiraserver', 'story_url').format(projectKey, update_filter, start)
                elif type.lower() == 'bugs':
                    url = config.get('Jiraserver', 'bugs_url').format(story, update_filter, start)
                else:
                    print('issue type will not supported.')
                    return

                response = requests.request(
                    "GET",
                    url,
                    headers=headers
                )
                # Decode Json string to Python
                if response.status_code == 200:
                    json_data = json.loads(response.text)

                    # Display issues
                    total_count = json_data["total"]
                    itr_cnt = math.ceil(total_count / maxResults)
                    start = index * maxResults
                    if itr_cnt >= index:
                        index = (index + 1)
                        if type.lower() == 'epic':
                            epic = self.extract_epic(json_data["issues"])
                            pf_epic = pd.concat([pf_epic, epic])

                        elif type.lower() == 'story':
                            stories, dat_story = self.extract_story(json_data["issues"])
                            self.stories = self.stories + stories
                            self.pf_stories = pd.concat([self.pf_stories, dat_story])

                        elif type.lower() == 'bugs':
                            dat_bugs= self.extract_bugs(json_data["issues"])
                            print(dat_bugs)
                            self.pf_bugs = pd.concat([self.pf_bugs, dat_bugs])

                if type.lower() == 'epic':
                    return pf_epic
                elif type.lower() == 'story':
                    return self.stories, self.pf_stories
                elif type.lower() == 'bugs':
                    return self.pf_bugs

        except Exception as e:
            error_msg = "[Error] Fail to extract jira data.\n :: %s" % e.__str__()
            print(error_msg)


    def extract_epic(self, items):
        """
        Extract epic data and update the dataframe
        Args:
             list of Issues(Epic items)
        Returns:
            Epic Dataframe
        """
        data_set_epic = []
        try:
            for item in items:
                projName = item['fields']['project']['name'] if 'project' in item['fields'] else ''
                Key = item['key']
                issueType = item['fields']['issuetype']['name'] if 'issuetype' in item['fields'] else ''
                summary = item['fields']['summary'] if 'summary' in item['fields'] else ''
                status = item['fields']['status']['name'] if 'status' in item['fields'] else ''
                parentKey = item['fields']['customfield_11738'] if 'customfield_11738' in item['fields'] else ''
                epicName = item['fields']['customfield_10005'] if 'customfield_10005' in item['fields'] else ''

                data_set_epic.append([
                    projName,
                    Key,
                    issueType,
                    summary,
                    status,
                    parentKey,
                    epicName
                ])
            dataset_epic = pd.DataFrame(data_set_epic)
            dataset_epic.columns = [
                'jv3_projects_base.NAME',
                'jv3_issues.KEY',
                'jv3_issues.ISSUE_TYPE',
                'jv3_issues.SUMMARY',
                'jv3_status.STATUS',
                'jv3_epic_parent.KEY',
                'jv3_epic_name'
            ]
        except Exception as e:
            error_msg = "[Error] Fail to extract epic data.\n :: %s" % e.__str__()
            print(error_msg)
        return dataset_epic

    def extract_story(self, items):
        """
         Extract stories and bugs data and update the dataframe
         Args:
             list of Issues(Story items)
         Returns:
             story and bugs Dataframe
         """
        data_set_story = []
        stories =[]
        bugs = []
        try:
            for item in items:
                projName = item['fields']['project']['name'] if 'project' in item['fields'] else ''
                storyKey = item['key']
                stories.append(storyKey)
                issueType = item['fields']['issuetype']['name'] if 'issuetype' in item['fields'] else ''
                summary = item['fields']['summary'] if 'summary' in item['fields'] else ''
                storyStatus = item['fields']['status']['name'] if 'status' in item['fields'] else ''
                parentKey = item['fields']['customfield_10006'] if 'customfield_10006' in item['fields'] else ''
                links = item['fields']['issuelinks'] if 'issuelinks' in item['fields'] else ''
                key = ''
                epic_name = item['fields']['customfield_10006'] if 'customfield_10006' in item['fields'] else ''
                story_id = item['id']
                updated = item['fields']['updated'] if 'updated' in item['fields'] else ''
                lbls = ''
                if 'labels' in item['fields'] and item['fields']['labels'] is not None:
                    labels = item['fields']['labels'] if 'labels' in item['fields'] else ''
                lbls = ','.join(map(str, labels))

                data_set_story.append([
                    projName,
                    storyKey,
                    issueType,
                    summary,
                    storyStatus,
                    parentKey,
                    updated,
                    lbls
                ])
            dataset_story = pd.DataFrame(data_set_story)
            dataset_story.columns = [
                'jv3_projects_base.NAME',
                'jv3_issues.KEY',
                'jv3_issues.ISSUE_TYPE',
                'jv3_issues.SUMMARY',
                'jv3_status.STATUS',
                'jv3_story_parent.story_parent_key',
                'jv3_issue_updated.UPDATED',
                'jv3_issue.LABELS'
            ]

        except Exception as e:
            error_msg = "[Error] Fail to extract tests data.\n :: %s" % e.__str__()
            print(error_msg)
        return stories, dataset_story

    def extract_bugs(self, items):
        """
        Extract bug data and update the dataframe
        Args:
            bug -  bug data
        Returns:
            bug Dataset
        """
        data_set_issue = []
        try:
            for bug in items:
                if bug is not None:
                    print(bug['id'])
                    comps = bug['fields']['components'] if 'components' in bug['fields'] else ''
                    issuecomps = ''
                    if len(comps) > 0:
                        for i in range(len(comps)):
                            issuecomps = issuecomps + ',' + comps[i]['name']
                    assignee = ''
                    if bug['fields']['assignee'] is not None:
                        assignee = bug['fields']['assignee']['name'] if 'assignee' in bug['fields'] else ''
                    lbls = ''
                    if 'labels' in bug['fields'] and bug['fields']['labels'] is not None:
                        labels = bug['fields']['labels'] if 'labels' in bug['fields'] else ''
                    lbls = ','.join(map(str, labels))

                    resloution = ''
                    if 'resolution' in bug['fields'] and bug['fields']['resolution'] is not None:
                        resloution = bug['fields']['resolution']['name']
                    temp = ''
                    if 'customfield_10605' in bug['fields'] and bug['fields']['customfield_10605'] is not None:
                        temp = bug['fields']['customfield_10605']['value']

                    links = bug['fields']['issuelinks'] if 'issuelinks' in bug['fields'] else ''
                    if len(links) == 0:
                        links.append({'outwardIssue': {'key': '', 'fields':{ 'summary':''}}})
                    storyKey=''
                    storyName=''
                    for index in range(len(links)):
                        storyKey = links[index]['outwardIssue']['key'] if 'outwardIssue' in links[index] else None
                        storyName = links[index]['outwardIssue']['fields']['summary'] if 'outwardIssue' in links[index] else ''
                        if storyKey is None:
                            storyKey = links[index]['inwardIssue']['key'] if 'inwardIssue' in links[index] else ''
                            storyName = links[index]['inwardIssue']['fields']['summary']  if 'inwardIssue' in links[index] else ''

                    data_set_issue.append([
                        bug['fields']['project']['key'] if 'project' in bug['fields'] else '',
                        bug['fields']['project']['name'] if 'project' in bug['fields'] else '',
                        bug['fields']['issuetype']['name'] if 'issuetype' in bug['fields'] else '',
                        bug['key'],
                        bug['fields']['status']['name'] if 'status' in bug['fields'] else '',
                        resloution,
                        bug['fields']['status']['statusCategory']['name'] if 'statusCategory' in bug['fields'][
                            'status'] else '',
                        temp,
                        bug['fields']['summary'] if 'summary' in bug['fields'] else '',
                        bug['fields']['priority']['name'] if 'priority' in bug['fields'] else '',
                        bug['fields']['creator']['name'] if 'creator' in bug['fields'] else '',
                        assignee,
                        bug['fields']['created'] if 'created' in bug['fields'] else '',
                        issuecomps,
                        bug['fields']['updated'] if 'updated' in bug['fields'] else '',
                        lbls,
                        storyKey,
                        storyName
                    ])
            dataset_bugs = pd.DataFrame(data_set_issue)
            dataset_bugs.columns = [
                'jv3_projects_base.KEY',
                'jv3_projects_base.NAME',
                'jv3_issues.ISSUE_TYPE',
                'jv3_issues.KEY',
                'jv3_status.STATUS',
                'jv3_custom_single_select_fields.bug_resolution',
                'jv3_custom_single_select_fields.validation_status',
                'jv3_custom_single_select_fields.SEVERITY',
                'jv3_issues.SUMMARY',
                'jv3_issues.PRIORITY',
                'jv3_creator.CREATOR',
                'jv3_assignee.ASSIGNEE',
                'jv3_issues.CREATED',
                'jv3_components_list.components_list',
                'updated',
                'labels',
                'story_key',
                'story_name'
            ]
        except Exception as e:
            error_msg = "[Error] Fail to extract tests data.\n :: %s" % e.__str__()
            print(error_msg)
        return dataset_bugs

    def getBugs(self, url):
        """Issue a GET request (read) against the API to get
        the issues for given url,
        Args:
            url - url to the issue
        Returns:
            response as json issue data
        """

        try:
            cred = "Basic " + base64.b64encode(b'manigandan.s@hp.com:Nikath@06').decode("utf-8")
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": cred
            }
            headers = {
                'Authorization': 'Basic bWFuaWdhbmRhbi5zQGhwLmNvbTpvZERJVGRyWHUwaEswSU8yUWJkeUxpVFNoMHVPblkxT3Y0V1J2eA==',
                'Cookie': 'AWSALB=2juJ9z7fMwKa0f8V/bNJv7ffpdWySY9mylJp1x0njpT4UlESm3/XxeIf3Wtz63TBzySuumJR3MEgRA7XjW34ZtxJ5QvmENORtvL2MiwqcuxrcZAIfc0VXu1QPBRZ; AWSALBCORS=2juJ9z7fMwKa0f8V/bNJv7ffpdWySY9mylJp1x0njpT4UlESm3/XxeIf3Wtz63TBzySuumJR3MEgRA7XjW34ZtxJ5QvmENORtvL2MiwqcuxrcZAIfc0VXu1QPBRZ; JSESSIONID=0FE543BAC09BCD2DA8F0AD39A2A26B25; atlassian.xsrf.token=B6PH-08EC-IZ9H-PNPV_d5b06c157b23fc5483e239bbedbd23d042ae040b_lin'
            }

            # Send request and get response
            response = requests.request(
                "GET",
                url,
                headers=headers
            )
            if response.status_code == 200:
                return json.loads(response.text)

            else:
                return response.text
        except pyodbc.Error as ex:
            sqlstate = ex.args[1]
            print(sqlstate)

    def submitSQL(self, df, tableName):
        """update the table with given dataframe.
        Args: df to update, table name
        Returns:
        """

        db_ins = SQLManager()
        exist_statement = 'SELECT COUNT(*) FROM %s' % tableName
        rows = db_ins.runQuery(exist_statement)
        if rows == 0:
            create_statement = 'CREATE TABLE %s (dummy int NOT NULL)' % tableName
            try:
                db_ins.runQuery(create_statement)
            except Exception as e:
                error_msg = "[Error] Fail to create table.\n :: %s" % e.__str__()
                print(error_msg)

        duplicate_statement = 'SELECT * INTO temp_tr FROM %s' % tableName
        db_ins.runQuery(duplicate_statement)
        delete_statement = 'DROP TABLE temp_tr'

        try:
            df.to_sql(name=tableName, con=db_ins.engine, if_exists='replace', index=False)
            db_ins.runQuery(delete_statement)
        except Exception as e:
            restore_statement = 'CREATE TABLE %s SELECT * FROM temp_tr' % tableName
            db_ins.runQuery(restore_statement)
            db_ins.runQuery(delete_statement)
            error_msg = "[Error] Fail to submit data to table.\n :: %s" % e.__str__()
            print(error_msg)

    def selectSQL(self, tableName):
        """get all the data from the table query.
        Args: tablename
        Returns: table data as dataframe
        """

        db_ins = SQLManager()
        df = pd.read_sql_table(table_name=tableName, con=db_ins.engine)
        return df

        exist_statement = 'SELECT COUNT(*) FROM %s' % tableName
        rows = db_ins.runQuery(exist_statement)
        if rows == 0:
            create_statement = 'CREATE TABLE %s (dummy int NOT NULL)' % tableName
            try:
                db_ins.runQuery(create_statement)
            except Exception as e:
                error_msg = "[Error] Fail to create table.\n :: %s" % e.__str__()
                print(error_msg)

        duplicate_statement = 'SELECT * INTO temp_tr FROM %s' % tableName
        db_ins.runQuery(duplicate_statement)
        delete_statement = 'DROP TABLE temp_tr'

        try:
            df.to_sql(name=tableName, con=db_ins.engine, if_exists='replace', index=False)
            db_ins.runQuery(delete_statement)
        except Exception as e:
            restore_statement = 'CREATE TABLE %s SELECT * FROM temp_tr' % tableName
            db_ins.runQuery(restore_statement)
            db_ins.runQuery(delete_statement)
            error_msg = "[Error] Fail to submit data to table.\n :: %s" % e.__str__()
            print(error_msg)

    def checkTableExists(self, tableName):
        db_ins = SQLManager()
        return db_ins.checkTableExists(tableName)

class JiraConnectionManagerError(Exception):
    pass
