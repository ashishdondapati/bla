#-*-coding:utf-8-*-

import sys, os
import time
import json
import datetime
from connector.Testrail_lib import *



"""
For getting Milestones using API from testrail
119 : Workpath
227 : OEM-X Kruger
182 : HPCC
164 : POtG
225 : WHF
"""

class ETLTR:
    """  
    To do gathering data from testrail.
    To do modeling collected data.
    To do submit data to SQL.
    """
    def extract(self, type_area):
        """Pull data from testrail using API.

        Args:

        Returns:
        
        """
        testrail_et = testrail_modeling() 
        return testrail_et.extract(type_area)

    def transform(self, mock_df, type, type_area):
        """Modeling data using dynamic query.

        Args:

        Returns:

        """
        if type_area == 'K':
            try:
                if type == 'runs':
                    mock_df['runs.assignedto_id'] = mock_df['runs.assignedto_id'].fillna(0).astype(int)
                    mock_df['runs.assignedto_id'].astype('int')
                    mock_df['runs.completed_on'] = mock_df['runs.completed_on'].fillna(0).astype(int)
                    mock_df['runs.completed_on'].astype('int')
                    mock_df['runs.created_on'] = mock_df['runs.created_on'].fillna(0).astype(int)
                    mock_df['runs.created_on'].astype('int')
                    del mock_df['runs.config']
                    del mock_df['runs.config_ids']
                    return mock_df

                elif type == 'tests':
                    mock_df['tests.assignedto_id'] = mock_df['tests.assignedto_id'].fillna(0).astype(int)
                    mock_df['tests.assignedto_id'].astype('int')
                    mock_df['tests.custom_automationstatus'] = mock_df['tests.custom_automationstatus'].fillna(0).astype(int)
                    mock_df['tests.custom_automationstatus'].astype('int')
                    mock_df['tests.custom_hpsm_component_area'] = mock_df['tests.custom_hpsm_component_area'].fillna(0).astype(int)
                    mock_df['tests.custom_hpsm_component_area'].astype('int')
                    mock_df['tests.custom_coverage'] = mock_df['tests.custom_coverage'].fillna(0).astype(int)
                    mock_df['tests.custom_coverage'].astype('int')
                    mock_df['tests.custom_weight'] = mock_df['tests.custom_weight'].fillna(0).astype(int)
                    mock_df['tests.custom_weight'].astype('int')
                    del mock_df['tests.custom_preconds']
                    del mock_df['tests.custom_procedure_attachments']
                    del mock_df['tests.custom_output_attachments']
                    del mock_df['tests.custom_steps_separated']
                    return mock_df

            except Exception as e:
                error_msg = "[Error] Fail to transform data.\n :: %s" % e.__str__()
                print(error_msg)

        elif type_area == 'T':
            try:
                if type == 'runs':
                    mock_df['runs.assignedto_id'] = mock_df['runs.assignedto_id'].fillna(0).astype(int)
                    mock_df['runs.assignedto_id'].astype('int')
                    mock_df['runs.completed_on'] = mock_df['runs.completed_on'].fillna(0).astype(int)
                    mock_df['runs.completed_on'].astype('int')
                    mock_df['runs.created_on'] = mock_df['runs.created_on'].fillna(0).astype(int)
                    mock_df['runs.created_on'].astype('int')
                    del mock_df['runs.config']
                    del mock_df['runs.config_ids']
                    return mock_df

                elif type == 'tests':
                    mock_df['tests.assignedto_id'] = mock_df['tests.assignedto_id'].fillna(0).astype(int)
                    mock_df['tests.assignedto_id'].astype('int')
                    mock_df['tests.custom_coverage'] = mock_df['tests.custom_coverage'].fillna(0).astype(int)
                    mock_df['tests.custom_coverage'].astype('int')
                    del mock_df['tests.custom_preconds']
                    del mock_df['tests.custom_steps_separated']
                    return mock_df

            except Exception as e:
                error_msg = "[Error] Fail to transform data.\n :: %s" % e.__str__()
                print(error_msg)
            
    def load(self, mock_df, tableName):
        """Submit data in list into the SQL.

        Args:

        Returns:

        """
        testrail_ld = testrail_modeling() 
        testrail_ld.submitSQL(mock_df, tableName)
        
    def tmpList(self, row, column):
        """Make temporary list to save data what it will be used once

        Args:
            row : row size of array
            column : column size of array

        Returns:
            list
        """

def etl_conf():
    
    etl_mock_data = ETLTR()

    ########################################SIV_K########################################
    type_area = 'K'
    m_milestone, m_submilestone, m_plan, m_run, m_test = etl_mock_data.extract(type_area)
    #Gathering data from Testrail via APIs

    m_run = etl_mock_data.transform(m_run, 'runs', type_area)
    m_test = etl_mock_data.transform(m_test, 'tests', type_area)
    #Modify Data to insert SQL Server

    etl_mock_data.load(m_milestone, "Milestones")
    etl_mock_data.load(m_submilestone, "SubMilestones")
    etl_mock_data.load(m_plan, "Plans")
    etl_mock_data.load(m_run, "Runs")
    etl_mock_data.load(m_test, "Tests")
    #Create Tables and submit to SQL Server
    ########################################SIV_K########################################


    ########################################SIV_T########################################
    type_area = 'T'
    m_milestone, m_submilestone, m_plan, m_run, m_test, m_sections, m_cases, m_results = etl_mock_data.extract(type_area)
    #Gathering data from Testrail via APIs

    m_run = etl_mock_data.transform(m_run, 'runs', type_area)
    m_test = etl_mock_data.transform(m_test, 'tests', type_area)
    #Modify Data to insert SQL Server

    etl_mock_data.load(m_milestone, "Milestones_SIVT")
    etl_mock_data.load(m_submilestone, "SubMilestones_SIVT")
    etl_mock_data.load(m_plan, "Plans_SIVT")
    etl_mock_data.load(m_run, "Runs_SIVT")
    etl_mock_data.load(m_test, "Tests_SIVT")

    etl_mock_data.load(m_sections, "Sections_SIVT")
    etl_mock_data.load(m_cases, "Cases_SIVT")
    etl_mock_data.load(m_results, "Results_SIVT")
    #Create Tables and submit to SQL Server
    ########################################SIV_T########################################




etl_conf()